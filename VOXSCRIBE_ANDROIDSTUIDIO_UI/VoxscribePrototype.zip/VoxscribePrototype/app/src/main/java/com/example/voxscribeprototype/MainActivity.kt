package com.example.voxscribeprototype

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val darkTheme = remember { mutableStateOf(false) }
            MaterialTheme(colorScheme = if (darkTheme.value) customDarkColors else customLightColors) {
                AppScreen(this, darkTheme)
            }
        }
    }
}

val customLightColors = lightColorScheme(
    primary = Color(0xFF007AFF),
    secondary = Color(0xFFE5E5EA),
    background = Color(0xFFF2F2F7),
    surface = Color.White,
    onPrimary = Color.White,
    onBackground = Color.Black,
    onSurface = Color(0xFF333333)
)

val customDarkColors = darkColorScheme(
    primary = Color(0xFF0A84FF),
    secondary = Color(0xFF636366),
    background = Color(0xFF1C1C1E),
    surface = Color(0xFF2C2C2E),
    onPrimary = Color.Black,
    onBackground = Color.White,
    onSurface = Color(0xFFD1D1D6)
)

@Composable
fun AppScreen(context: Context, darkTheme: MutableState<Boolean>) {
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        floatingActionButton = {
            AnimatedVisibility(visible = selectedTab == 1) {
                FloatingActionButton(
                    onClick = { /* Handle new notebook */ },
                    containerColor = MaterialTheme.colorScheme.primary
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Notebook")
                }
            }
        },
        bottomBar = { BottomNavigationBar(selectedTab) { index -> selectedTab = index } }
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            when (selectedTab) {
                0 -> RecognizeScreen()
                1 -> NotebooksScreen(context)
                2 -> SettingsScreen(darkTheme)
            }
        }
    }
}

@Composable
fun RecognizeScreen() {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.surface)
                .clickable {}, // TODO: Implement Image Upload
            contentAlignment = Alignment.Center
        ) {
            Text("Take or Upload an Image", fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)
        }
        Spacer(modifier = Modifier.height(28.dp))
        ActionButton("Recognize")
        Spacer(modifier = Modifier.height(20.dp))
        ActionButton("Write Text")
    }
}

@Composable
fun ActionButton(text: String) {
    var scale by remember { mutableStateOf(1f) }
    val animatedScale by animateFloatAsState(targetValue = scale)
    Button(
        onClick = {
            scale = 0.9f
            scale = 1.1f
        },
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(RoundedCornerShape(20.dp))
            .scale(animatedScale)
    ) {
        Text(text, fontSize = 18.sp, color = Color.White)
    }
}

val Context.dataStore by preferencesDataStore("notebooks")

// Persistent Storage Helper
class DataStoreHelper(private val context: Context) {
    companion object {
        val NOTEBOOKS_KEY = stringPreferencesKey("notebooks")
        val PAGES_KEY = stringPreferencesKey("pages")
    }

    suspend fun saveNotebooks(notebooks: List<String>) {
        context.dataStore.edit { preferences ->
            preferences[NOTEBOOKS_KEY] = notebooks.joinToString("|")
        }
    }

    suspend fun getNotebooks(): List<String> {
        val preferences = context.dataStore.data.map { it[NOTEBOOKS_KEY] ?: "" }.first()
        return if (preferences.isNotEmpty()) preferences.split("|") else emptyList()
    }

    suspend fun savePages(notebookName: String, pages: List<String>) {
        context.dataStore.edit { preferences ->
            preferences[stringPreferencesKey("pages_$notebookName")] = pages.joinToString("|")
        }
    }

    suspend fun getPages(notebookName: String): List<String> {
        val key = stringPreferencesKey("pages_$notebookName")
        val preferences = context.dataStore.data.map { it[key] ?: "" }.first()
        return if (preferences.isNotEmpty()) preferences.split("|") else emptyList()
    }
}
// 📕 Notebooks Screen with DataStore Integration
@Composable
fun NotebooksScreen(context: Context) {
    val dataStore = remember { DataStoreHelper(context) }
    val notebooks = remember { mutableStateListOf<String>() }
    var notebookName by remember { mutableStateOf("") }
    var selectedNotebook by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        val savedNotebooks = dataStore.getNotebooks()
        notebooks.clear()
        notebooks.addAll(savedNotebooks)
    }

    AnimatedVisibility(
        visible = true,
        enter = fadeIn(animationSpec = tween(500)),
        exit = fadeOut(animationSpec = tween(500))
    ) {
        if (selectedNotebook == null) {
            Column(modifier = Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = notebookName,
                    onValueChange = { notebookName = it },
                    label = { Text("Notebook Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (notebookName.isNotBlank()) {
                            notebooks.add(notebookName)
                            notebookName = ""
                            CoroutineScope(Dispatchers.IO).launch { dataStore.saveNotebooks(notebooks) }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Add Notebook") }
                Spacer(modifier = Modifier.height(8.dp))
                LazyColumn {
                    itemsIndexed(notebooks) { index, notebook ->
                        AnimatedVisibility(
                            visible = true,
                            enter = fadeIn(animationSpec = tween(500)),
                            exit = fadeOut(animationSpec = tween(500))
                        ) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(4.dp)
                                    .clickable { selectedNotebook = notebook },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = notebook, fontSize = 18.sp)
                                    IconButton(onClick = {
                                        notebooks.removeAt(index)
                                        CoroutineScope(Dispatchers.IO).launch { dataStore.saveNotebooks(notebooks) }
                                    }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete Notebook", tint = Color.Red)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            NotebookDetailScreen(context, selectedNotebook!!) { selectedNotebook = null }
        }
    }
}

@Composable
fun NotebookDetailScreen(context: Context, notebookName: String, onBack: () -> Unit) {
    val dataStore = remember { DataStoreHelper(context) }
    val pages = remember { mutableStateListOf<String>() }
    var newPageContent by remember { mutableStateOf("") }
    var selectedPage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        val savedPages = dataStore.getPages(notebookName)
        pages.clear()
        pages.addAll(savedPages)
    }

    AnimatedVisibility(
        visible = true,
        enter = fadeIn(animationSpec = tween(500)) + expandVertically(),
        exit = fadeOut(animationSpec = tween(400)) + shrinkVertically()
    ) {
        if (selectedPage == null) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                AnimatedVisibility(
                    visible = true,
                    enter = fadeIn(animationSpec = tween(500)),
                    exit = fadeOut(animationSpec = tween(300))
                ) {
                    Button(
                        onClick = onBack,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    ) {
                        Text("Back to Notebooks")
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(modifier = Modifier.weight(1f)) {
                    itemsIndexed(pages) { index, page ->
                        AnimatedVisibility(
                            visible = true,
                            enter = fadeIn(animationSpec = tween(500)) + slideInVertically(initialOffsetY = { it / 2 }),
                            exit = fadeOut(animationSpec = tween(400)) + slideOutVertically(targetOffsetY = { it / 2 })
                        ) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(4.dp)
                                    .clickable { selectedPage = page },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(text = page, fontSize = 18.sp)
                                    IconButton(onClick = {
                                        pages.removeAt(index)
                                        CoroutineScope(Dispatchers.IO).launch { dataStore.savePages(notebookName, pages) }
                                    }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete Page", tint = Color.Red)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = newPageContent,
                    onValueChange = { newPageContent = it },
                    label = { Text("New Page Content") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                val scale by animateFloatAsState(
                    targetValue = if (newPageContent.isNotBlank()) 1.05f else 1f,
                    animationSpec = tween(durationMillis = 300)
                )

                Button(
                    onClick = {
                        if (newPageContent.isNotBlank()) {
                            pages.add(newPageContent)
                            newPageContent = ""
                            CoroutineScope(Dispatchers.IO).launch { dataStore.savePages(notebookName, pages) }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .scale(scale)
                        .clip(RoundedCornerShape(12.dp))
                ) {
                    Text("Add Page")
                }
            }
        } else {
            NoteTakingScreen(context, notebookName, selectedPage!!, pages, onBack = { selectedPage = null })
        }
    }
}




// 📝 Updated NoteTakingScreen to correctly save edits
@Composable
fun NoteTakingScreen(context: Context, notebookName: String, pageContent: String, pages: MutableList<String>, onBack: () -> Unit) {
    val dataStore = remember { DataStoreHelper(context) }
    var noteContent by remember { mutableStateOf(pageContent) }
    var isBold by remember { mutableStateOf(false) }
    var isItalic by remember { mutableStateOf(false) }
    var isUnderline by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp).background(MaterialTheme.colorScheme.background),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
        ) {
            Text("Back to Notebook", fontSize = 18.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Formatting Toolbar
        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            IconButton(onClick = { isBold = !isBold }) {
                Icon(Icons.Default.FormatBold, contentDescription = "Bold")
            }
            IconButton(onClick = { isItalic = !isItalic }) {
                Icon(Icons.Default.FormatItalic, contentDescription = "Italic")
            }
            IconButton(onClick = { isUnderline = !isUnderline }) {
                Icon(Icons.Default.FormatUnderlined, contentDescription = "Underline")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Note Editor
        OutlinedTextField(
            value = noteContent,
            onValueChange = { noteContent = it },
            label = { Text("Write your notes...") },
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.7f).clip(RoundedCornerShape(12.dp)),
            textStyle = TextStyle(
                fontSize = 18.sp,
                fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
                fontStyle = if (isItalic) FontStyle.Italic else FontStyle.Normal,
                textDecoration = if (isUnderline) TextDecoration.Underline else TextDecoration.None
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Save Note Button (Correctly updates DataStore)
        Button(
            onClick = {
                val index = pages.indexOf(pageContent)
                if (index != -1) {
                    pages[index] = noteContent // Update existing page
                } else {
                    pages.add(noteContent) // If not found, add new page
                }

                CoroutineScope(Dispatchers.IO).launch {
                    dataStore.savePages(notebookName, pages)
                }

                onBack()
            },
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
        ) {
            Text("Save Note", fontSize = 18.sp)
        }
    }
}

@Composable
fun SettingsScreen(darkTheme: MutableState<Boolean>) {
    Box(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Settings", fontSize = 24.sp, color = MaterialTheme.colorScheme.onBackground)
            Spacer(modifier = Modifier.height(16.dp))

            // Use the animated button to toggle dark mode
            AnimatedButton(darkTheme)

            Spacer(modifier = Modifier.height(20.dp))
            Text("© Developed and maintained by Abhinava Bugudi", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
        }
    }
}


@Composable
fun ToggleThemeButton(darkTheme: MutableState<Boolean>) {
    val animatedRotation by animateFloatAsState(targetValue = if (darkTheme.value) 180f else 0f)
    IconButton(onClick = { darkTheme.value = !darkTheme.value }) {
        Icon(
            imageVector = if (darkTheme.value) Icons.Filled.Brightness7 else Icons.Filled.Brightness4,
            contentDescription = "Toggle Theme",
            modifier = Modifier.size(56.dp).rotate(animatedRotation),
            tint = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
fun NoteTakingScreen(pageContent: String, onBack: () -> Unit) {
    var noteContent by remember { mutableStateOf(pageContent) }
    var isBold by remember { mutableStateOf(false) }
    var isItalic by remember { mutableStateOf(false) }
    var isUnderline by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .background(MaterialTheme.colorScheme.background),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Back Button
        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
        ) {
            Text("Back to Notebook", fontSize = 18.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Formatting Toolbar
        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            IconButton(onClick = { isBold = !isBold }) {
                Icon(Icons.Default.FormatBold, contentDescription = "Bold")
            }
            IconButton(onClick = { isItalic = !isItalic }) {
                Icon(Icons.Default.FormatItalic, contentDescription = "Italic")
            }
            IconButton(onClick = { isUnderline = !isUnderline }) {
                Icon(Icons.Default.FormatUnderlined, contentDescription = "Underline")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Note Editor
        OutlinedTextField(
            value = noteContent,
            onValueChange = { noteContent = it },
            label = { Text("Write your notes...") },
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.7f).clip(RoundedCornerShape(12.dp)),
            textStyle = TextStyle(
                fontSize = 18.sp,
                fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
                fontStyle = if (isItalic) FontStyle.Italic else FontStyle.Normal,
                textDecoration = if (isUnderline) TextDecoration.Underline else TextDecoration.None
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Save Note Button
        Button(
            onClick = { onBack() },
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
        ) {
            Text("Save Note", fontSize = 18.sp)
        }
    }
}

@Composable
fun BottomNavigationBar(selectedTab: Int, onTabSelected: (Int) -> Unit) {
    NavigationBar {
        val items = listOf(
            NavigationItem("Recognize", Icons.Filled.Create),
            NavigationItem("Notebooks", Icons.Filled.Book),
            NavigationItem("Settings", Icons.Filled.Settings)
        )
        items.forEachIndexed { index, item ->
            NavigationBarItem(
                icon = { Icon(imageVector = item.icon, contentDescription = item.label) },
                label = { Text(item.label) },
                selected = selectedTab == index,
                onClick = { onTabSelected(index) }
            )
        }
    }
}

@Composable
fun AnimatedButton(darkTheme: MutableState<Boolean>) {
    val rotation by animateFloatAsState(
        targetValue = if (darkTheme.value) 180f else 0f,
        animationSpec = tween(durationMillis = 400)
    )

    Button(
        onClick = { darkTheme.value = !darkTheme.value },
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .size(80.dp) // Increased button size
            .rotate(rotation)
    ) {
        Icon(
            imageVector = if (darkTheme.value) Icons.Filled.Brightness7 else Icons.Filled.Brightness4,
            contentDescription = "Toggle Theme",
            tint = Color.White,
            modifier = Modifier.size(40.dp) // Increased icon size
        )
    }
}



data class NavigationItem(val label: String, val icon: ImageVector)